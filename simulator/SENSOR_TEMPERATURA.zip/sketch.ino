#include "DHT.h"

// PINES
#define DHT_PIN 15
#define DHT_TYPE  DHT22
#define LED_PIN 2

//OBJETO DHT22
DHT dht(DHT_PIN,DHT_TYPE);

//CONFIGURACION
const char* DEVICE_ID  = "ESP32_MACHINE_001";
const char* MACHINE_ID = "MACHINE_001";

// ALARMA
const float TEMPERATURE_LIMIT = 90.0;
const float VIBRATION_LIMIT   = 10.0;

// LECTURA
const unsigned long READ_INTERVAL = 2000;
unsigned long lastRead = 0;

// CONFIGURACION

void setup(){
  Serial.begin(115200);

  delay(1000);

  Serial.println();
  Serial.println("========================================");
  Serial.println("     INDUSTRIAL IoT - MACHINE 001");
  Serial.println("========================================");

  // LED
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // Iniciar DHT22
  dht.begin();

  Serial.println("ESP32 iniciado correctamente.");
  Serial.println("DHT22 inicializado.");
  Serial.println("Potenciometro configurado como vibracion.");
  Serial.println("Sistema listo.");
  Serial.println();
}

void loop() {

  // Ejecutar lectura cada READ_INTERVAL
  if (millis() - lastRead >= READ_INTERVAL) {

    lastRead = millis();

    // LEER DHT22
    float temperature = dht.readTemperature();
    float humidity    = dht.readHumidity();

    // LEER POTENCIÓMETRO
    int analogValue = analogRead(VIBRATION_PIN);

    // Convertir 0-4095 a 0-15 mm/s
    float vibration = (analogValue / 4095.0) * 15.0;

    // VALIDAR DHT22
    if (isnan(temperature) || isnan(humidity)) {
      Serial.println("ERROR: No se pudo leer el DHT22.");
      return;
    }

    // DETERMINAR ESTADO DE LA MÁQUINA
    bool anomaly = false;

    if (temperature > TEMPERATURE_LIMIT) {
      anomaly = true;
    }

    if (vibration > VIBRATION_LIMIT) {
      anomaly = true;
    }

    // CONTROL DEL LED
    if (anomaly) {

      digitalWrite(LED_PIN, HIGH);

    } else {

      digitalWrite(LED_PIN, LOW);
    }

    // MOSTRAR RESULTADOS
    Serial.println("----------------------------------------");

    Serial.print("Device ID   : ");
    Serial.println(DEVICE_ID);

    Serial.print("Machine ID  : ");
    Serial.println(MACHINE_ID);

    Serial.print("Temperature : ");
    Serial.print(temperature, 2);
    Serial.println(" °C");

    Serial.print("Humidity    : ");
    Serial.print(humidity, 2);
    Serial.println(" %");

    Serial.print("Vibration   : ");
    Serial.print(vibration, 2);
    Serial.println(" mm/s");

    Serial.print("Analog      : ");
    Serial.println(analogValue);

    Serial.print("Status      : ");

    if (anomaly) {

      Serial.println("ANOMALY");

    } else {

      Serial.println("NORMAL");
    }

    Serial.print("Alarm       : ");

    if (anomaly) {

      Serial.println("ON");

    } else {

      Serial.println("OFF");
    }

    Serial.println("----------------------------------------");
  }
}